package hsai.prototype.fietsveilig;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MiniGamesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mini_games);
        setTitle("Minigames");
    }
}
