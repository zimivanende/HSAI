package hsai.prototype.fietsveilig.leaderboard;

import android.content.Context;

import java.util.ArrayList;
// TODO: use this class instead of always making a new arrayList for the images, usernames, scores & ranks
public class LeaderboardLine {
    private ArrayList<String> m_images = new ArrayList<>();
    private ArrayList<String> m_usernames = new ArrayList<>();
    private ArrayList<String> m_ranks = new ArrayList<>();
    private ArrayList<String> m_scores = new ArrayList<>();
    private Context m_context;

    public void sort() {

    }
}
